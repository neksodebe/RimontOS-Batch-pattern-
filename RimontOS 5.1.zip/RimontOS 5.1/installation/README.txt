 ________  ___  _____ ______   ________  ________   _________        ________  ________      
|\   __  \|\  \|\   _ \  _   \|\   __  \|\   ___  \|\___   ___\     |\   __  \|\   ____\     
\ \  \|\  \ \  \ \  \\\__\ \  \ \  \|\  \ \  \\ \  \|___ \  \_|     \ \  \|\  \ \  \___|_    
 \ \   _  _\ \  \ \  \\|__| \  \ \  \\\  \ \  \\ \  \   \ \  \       \ \  \\\  \ \_____  \   
  \ \  \\  \\ \  \ \  \    \ \  \ \  \\\  \ \  \\ \  \   \ \  \       \ \  \\\  \|____|\  \  
   \ \__\\ _\\ \__\ \__\    \ \__\ \_______\ \__\\ \__\   \ \__\       \ \_______\____\_\  \ 
    \|__|\|__|\|__|\|__|     \|__|\|_______|\|__| \|__|    \|__|        \|_______|\_________\
                                                                                 \|_________|
                                                                                             
If this logo is broken for you, open it in a software for programming. It should be better.                                                               




Hello! Thank you for downloading RimontOS!

Normally, this OS wouldn't work. Why? Read the line below \/ \/ \/ \/

Firstly, let's install and configure the system. To do this, you firstly need to start install.cmd. If you've been directed to a website, click the link to start downloading the
newest RimontOS. If you want to download the oldest version of RimontOS, click "Older versions" and select your version. If the site is offline, that means that the owner of
this OS didn't start the server yet. Wait a couple of minutes and try again. When the downloading is finished, unpack the ZIP, and start config.cmd as Administrator
After config.cmd has closed, run start.cmd
Done! RimontOS works now!


    ******************************************************************************************************************************************************
    *                                                                                                                                                    *
    * Please note that this OS is not a real Operating System. It is just a simulator. We're trying to make a real OS named RimontOS that is bootable.   *
    *                                                                                                                                                    *
    ******************************************************************************************************************************************************