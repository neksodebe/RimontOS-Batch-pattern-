public class colorTest {

    public static void main(String[] args) {
        System.out.println((char)27 + "[31m" + "ERROR MESSAGE IN RED");
    }
}